# BeautyProof 可运行源码包

## 运行环境

- Python 3.11
- 本包不包含 Python 第三方依赖、虚拟环境或 site-packages。依赖版本清单保存在 requirements.txt。
- 包含项目自训 AIGC v4 推理权重和独立离线演示页；不含 TruFor 第三方代码/权重、原始训练图片或评测图片集。

## Windows PowerShell 启动

在解压后的 BeautyProof 目录执行：

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install torch==2.14.0 torchvision==0.29.0 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python web/app.py
```

浏览器打开 http://127.0.0.1:5000。命令行单图快检：

```powershell
python tools/pipeline.py "图片路径.jpg" --fast
```

运行全模型分析时，项目内已包含 AIGC v4 权重；TruFor 需要按上游许可单独准备官方代码和权重。离线交互演示可直接打开 demo/index.html，无需安装 Python 包。

## 包含内容

- tools/：项目 Python 工具及流水线源码
- web/：Flask 演示服务和页面模板
- models/beautyproof_aigen_v4/：当前生产模型及配置
- data/：运行需要的文本案例、清单与自产演示图；不包含原始训练/评测图片
- demo/index.html：单文件离线演示
- LICENSE、NOTICE、源码和模型来源说明

不包含 Git 历史、测试目录、训练/评测数据集、提交用 PPT/视频/数据包、推送脚本及第三方依赖库。
